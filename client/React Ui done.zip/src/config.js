export const TwitterContractAddress = "0xd978eebe6CA9235881e259ac66Abf0C7eA69b5d3";

