export const defaultImgs = [
    "https://images.pexels.com/photos/12704642/pexels-photo-12704642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    "https://images.pexels.com/photos/10610221/pexels-photo-10610221.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
]